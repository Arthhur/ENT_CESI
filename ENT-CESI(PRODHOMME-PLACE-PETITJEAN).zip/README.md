# ENT_CESI

Back : API réalisée avec flask python   => python api.py
Front : réalisé avec le framework Svelte js   => npm run dev


Se connecter avec l'un des élèves de la bdd (mail + password)
