class Person:
    def __init__(self, prenom, nom):
        self.prenom = prenom
        self.nom = nom
