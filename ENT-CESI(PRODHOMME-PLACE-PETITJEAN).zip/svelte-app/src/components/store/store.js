import { writable } from 'svelte/store';

export const isAuth = writable(false);