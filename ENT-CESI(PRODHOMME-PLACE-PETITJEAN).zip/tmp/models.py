class Person:
    def __init__(self, prenom, nom):
        self.prenom = prenom
        self.nom = nom

class Promotion:
    def __init__(self, libelle, date_debut, date_fin):
        self.libelle = libelle
        self.date_debut = date_debut
        self.date_fin = date_fin
